// main.cpp  10 Dec 2023 - new wokwi project

// nick gammon - leave .ino empty .. that's it!

#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
}

void loop() {
  delay(10); // this speeds up the simulation
}
